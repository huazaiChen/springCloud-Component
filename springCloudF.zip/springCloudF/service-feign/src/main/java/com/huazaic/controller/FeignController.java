package com.huazaic.controller;

import com.huazaic.IServiceFeign;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * Created by lenovo on 2018/8/1.
 */
@RestController
public class FeignController {

    @Autowired
    IServiceFeign iServiceFeign;

    @RequestMapping("/sayHello")
    public String sayHello(@RequestParam String name){
        return iServiceFeign.sayHelloFromFeignOne(name);
    }
}

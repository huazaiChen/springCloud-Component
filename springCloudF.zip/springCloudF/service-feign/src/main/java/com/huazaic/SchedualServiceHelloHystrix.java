package com.huazaic;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

/**
 * Created by lenovo on 2018/8/1.
 */
@Component
public class SchedualServiceHelloHystrix implements IServiceFeign {

    private  final Logger logger = LoggerFactory.getLogger(SchedualServiceHelloHystrix.class);

    @Override
    public String sayHelloFromFeignOne(String name){
        logger.info("Service-Hello出现异常！请管理员尽快处理！");
        return "Sorry "+name;
    }

}

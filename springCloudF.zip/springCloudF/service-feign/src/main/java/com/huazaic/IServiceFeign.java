package com.huazaic;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

/**
 * Created by lenovo on 2018/8/1.
 */
@FeignClient(value = "SERVICE-HELLO",fallback = SchedualServiceHelloHystrix.class)
public interface IServiceFeign {

    @RequestMapping(value = "/sayHello",method = RequestMethod.GET)
    String sayHelloFromFeignOne(@RequestParam(value = "name") String name);
}

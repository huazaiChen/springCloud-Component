package com.huazaic.controller;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

/**
 * Created by lenovo on 2018/8/9.
 */
@RestController
@RefreshScope
public class ConfigController {

    @Value("${neo.hello}")
    private String hello;

    @GetMapping("/hello")
    public String reStr(){
        return hello;
    }
}

package com.huazaic.controller;

import brave.sampler.Sampler;
import com.huazaic.service.RibbonService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.netflix.ribbon.RibbonLoadBalancerClient;
import org.springframework.context.annotation.Bean;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * Created by lenovo on 2018/7/31.
 */
@RestController
public class RibbonController {


    @Autowired
    private RibbonService ribbonService;

    @RequestMapping("/getSayHello")
    public String getSayHello(@RequestParam String name){
        return ribbonService.helloService(name);
    }


    @Bean
    public Sampler defaultSampler() {
        return Sampler.ALWAYS_SAMPLE;
    }
}
